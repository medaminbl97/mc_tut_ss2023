#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <errno.h>



int _open (char *path, int oflag)
{
	int fd = 0;

	return fd;
}

int _write(int fd, const void *buf, size_t count)
{
	int i = 0;

	return i;
}


int _read(int fd, const void *buf, size_t count)
{
	int i = 0;
	
	return i;
}