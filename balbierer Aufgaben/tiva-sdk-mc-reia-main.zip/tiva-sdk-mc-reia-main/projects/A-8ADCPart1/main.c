#include <stdint.h>
#include <stdbool.h>
#include <TM4C123GH6PM.h>
/* Driverlib includes */
#include "inc/hw_memmap.h"


#include "printf.h"
#include "uart.h"


#include <string.h>


void init_adc()
{
   /**
    * 1) Initialisieren Sie hier den ADC mit der im Datenblatt 
    *    beschriebenen Reihenfolge. Folgende Konfiguration ist
    *    gewünscht:
    * 
    * SampleSequencer0:
    * - 4 x Abtasten des Temperatursensors
    * - Nach 4x Temperatursensor soll der Sequencer aufhören
    * - Es soll kein Interrupt ausgelöst werden
    * 
    * ADC Averaging: 
    * - Die Messwerte sollen 4x überabgetastet werden
    * 
    * ADC:
    * - 1 MSample / s
    * - Triggerung von SampleSequencer 0 durch den Prozessor
    */
}

void SysTick_Handler(void)
{
    /**
     * 2) Triggern Sie hier den Sample Sequencer 0,
     *    um eine Messung zu starten
     */
}

void init_systick()
{
    SysTick->CTRL = 0;         // Deaktivieren
    SysTick->LOAD = 15999999;  // Setzen des Reload Wertes (Interrupt jede Millisekunde)
    SysTick->VAL = 0;          // Zurücksetzen des Zählers
    SysTick->CTRL |= (1 << 2); // Auswahl der Prozessor Clock (16MHz)
    SysTick->CTRL |= (1 << 1); // Interrupts generieren
    SysTick->CTRL |= (1 << 0); // SysTick aktivieren
}

int main()
{
    uint32_t counter = 0;
    uint8_t rcvbuffer;

    init_uart();
    init_systick();
    init_adc();

    while (1)
    {
        /**
         * 3) Warten Sie hier in der Schleife darauf, dass 
         *    Daten im ADC Fifo von Sequencer 0 gelandet sind
         *    und der ADC nicht mehr BUSY ist
         */

        /** 
         * 4) Lesen Sie nun die Daten vom FIFO und berechnen
         *    Sie den Mittelwert
         */

        /**
         * 5) Berechnen Sie anhand der im Datenblatt gegebenen Formel
         *    und des in 4) berechneten Mittelwerts die aktuelle Temperatur 
         */

        /** 
         * 6) Geben Sie die Temperatur mittels printf aus
         */
    }
}
