#ifndef DEFINITIONS_H
#define  DEFINITIONS_H

typedef void (*pFunc)(void);

#endif