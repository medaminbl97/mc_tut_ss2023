
int my_function(int a, int b)
{
    return a + b;
}

int main()
{
    int x;

    x = my_function(42, 10);

    return 0;
}
