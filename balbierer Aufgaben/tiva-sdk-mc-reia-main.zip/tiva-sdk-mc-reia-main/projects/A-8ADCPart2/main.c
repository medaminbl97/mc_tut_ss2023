#include <stdint.h>
#include <stdbool.h>
#include <TM4C123GH6PM.h>
/* Driverlib includes */
#include "inc/hw_memmap.h"


#include "printf.h"
#include "uart.h"


#include <string.h>


void init_adc()
{
   /**
    * 1) Ändern sie die folgende Konfiguration so ab, dass ein Interrupt
    *    ausgelöst wird, wenn der Sequencer 0 fertig ist.
    */
    SYSCTL->RCGCADC |= (1 << 0);
    while (!(SYSCTL->PRADC & (1 << 0))) {}

    ADC0->SSPRI = 0;
    ADC0->PC = 0x7;
    ADC0->ACTSS &= ~(1 << 0);
    ADC0->EMUX = 0x0;
    ADC0->SSCTL0 = (1 << 3) | (1 << 7) | (1 << 11) | (1 << 15);
    ADC0->SSCTL0 |= (1 << 13);
    ADC0->ACTSS |= (1 << 0);
    ADC0->SAC = 0x02;
}

void SysTick_Handler(void)
{
    ADC0->PSSI |= (1 << 0);
}

void init_systick()
{
    SysTick->CTRL = 0;         // Deaktivieren
    SysTick->LOAD = 15999999;  // Setzen des Reload Wertes (Interrupt jede Millisekunde)
    SysTick->VAL = 0;          // Zurücksetzen des Zählers
    SysTick->CTRL |= (1 << 2); // Auswahl der Prozessor Clock (16MHz)
    SysTick->CTRL |= (1 << 1); // Interrupts generieren
    SysTick->CTRL |= (1 << 0); // SysTick aktivieren
}

/** 
 * 2) Implementieren Sie nun den Interrupt Service Handler.
 *    Der Handler soll 
 *    - die Daten vom ADC FIFO lesen, mitteln und in einer 
 *      globalen Variable speichern.
 *    - ein globales Flag setzen, dass neue Daten zur 
 *      Verfügung stehen
 *    - notwendige Verwaltungsarbeit leisten, so dass der Interrupt
 *      erneut ausgelöst werden kann
 */

int main()
{
    init_uart();
    init_systick();
    init_adc();

    while (1)
    {
        /**
         * 3) Prüfen Sie nun kontinuierlich, ob neue Daten vorhanden sind.
         *    Falls Daten vorhanden sind
         *    - berechnen Sie die Temperatur
         *    - Geben Sie die Temperatur aus
         *    - setzen Sie das Flag zurück
         */
    }
}
