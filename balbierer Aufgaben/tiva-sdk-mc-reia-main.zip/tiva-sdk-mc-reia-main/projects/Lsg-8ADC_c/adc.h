#ifndef ADCBYTIMER_H_
#define ADCBYTIMER_H_


extern float temperature;
extern float potentiometer;

void adcByTimer_init(void);

#endif
